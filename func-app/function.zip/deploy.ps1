az functionapp deployment source config-zip `
    --resource-group rg-algebra-project `
    --name aro-windows-function-app `
    --src function.zip